#include <avr/io.h>
#include <stdbool.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

#define LEDPORT	PORTE

#define XRES 40
#define YRES 32
#define BUFXSZ 40
#define BUFYSZ 32

#define XOFFSET 0x3FF
#define YOFFSET 0x3FF
#define DACMAX 0xAFF

bool buffer[BUFYSZ][BUFXSZ];
unsigned int xlookup[XRES];
unsigned int ylookup[YRES];

inline void paint(int y, int x){
	// CH0 = X, CH1 = y
	DACA.CH0DATA = xlookup[x];
	DACA.CH1DATA = ylookup[y];
}

void init(){
	/*Setup LEDPORT as the output port*/////
	LEDPORT.DIR = 0xFF;
	PORTCFG.MPCMASK = 0xFF;
	LEDPORT.PIN0CTRL = PORT_INVEN_bm;
	
	for(int i = 0; i < BUFYSZ; ++i)
		for(int j = 0; j < BUFXSZ; ++j)
			buffer[i][j] = false;


	float unitx = (DACMAX-XOFFSET)/(float)XRES;
	float unity = (DACMAX-YOFFSET)/(float)YRES;
	
	// Calculate xlookup and ylookup
	for(int i = 0; i < XRES; ++i)
		xlookup[i] = i*unitx + XOFFSET;	
	for(int i = 0; i < YRES; ++i)
		ylookup[i] = i*unity + YOFFSET;	

	// Setup DAC, allow as fast as possible converts
	DACA.CTRLA |= DAC_CH1EN_bm | DAC_CH0EN_bm | DAC_ENABLE_bm;
	DACA.CTRLB |= DAC_CHSEL_DUAL_gc;
	DACA.CTRLC |= DAC_REFSEL_AVCC_gc;
	DACA.TIMCTRL &= ~DAC_CONINTVAL_gm;
	DACA.TIMCTRL |= DAC_CONINTVAL_1CLK_gc;
	
	
	//Setup timer1 with overflow interrupt
	TCE1.CTRLA = TC_CLKSEL_DIV256_gc;
	TCE1.INTCTRLA = (TCE1.INTCTRLA & ~TC1_OVFINTLVL_gm) | TC_OVFINTLVL_MED_gc;
	// ~20 fps
	TCE1.PER = 0x0FA;
	
	//Enable medium levels interrupt globally
	PMIC.CTRL |= PMIC_MEDLVLEN_bm;

	//Enable global interrupts
	sei();

}

void swap(int* x, int* y)
{
	int temp = *x;
	*x = *y;
	*y = temp;
}

inline void drawPixel(int x, int y){
	buffer[y][x] = true;	
}

inline void drawRect(int x, int y, int width, int height){
	for(int i = 0; i < height; ++i){
	for(int j = 0; j < width; ++j){
		drawPixel(j+x, i+y);
	}
	}
}

inline void drawLine(int x0, int y0, int x, int y){
	if(x0 > x){
		drawLine(x, y, x0, y0);
		return;
	}

	if( abs(y - y0) > abs(x - x0) ){
		if(x-x0 == 0){
			drawRect(x0, y0>y?y:y0, 1, abs(y - y0));
			return;
		}
		int a = abs(y - y0) / abs(x - x0);

		for(int i = x0; i != x; x < x0? i-- : ++i){
			drawRect(i, (y0+=a), 1, a);
		}
	}
	else{	
		if((y-y0) == 0){
			drawRect(x0>x?x:x0, y0, abs(x-x0), 1);
			return;
		}
		int a = abs(x - x0) / abs(y - y0);
		for(int i = y0; i != y; y < y0? i-- : i++){
			drawRect((x0+=a), i, a, 1);
		}
	}
}

void drawPVV(){
	//P
	drawLine(0, 0, 0, 16);
	drawLine(0,16,2,16);
	drawLine(2,16,2,9);
	drawLine(2,9,5,9);
	drawLine(5,9,8,6);
	drawLine(8,6,8,3);
	drawLine(8,3,5,0);
	drawLine(5,0,0,0);

	drawLine(2,2,5,2);
	drawLine(5,2,6,3);
	drawLine(6,3,6,6);
	drawLine(6,6,5,7);
	drawLine(5,7,2,7);
	drawLine(2,7,2,2);

	//V1
	drawLine(9,0,11,0);
	drawLine(11,0,17,13);
	drawLine(17,13,23,0);
	drawLine(23,0,25,0);
	drawLine(25,0,19,16);
	drawLine(19,16,15,16);
	drawLine(15,16,9,0);
	
	//V2
	drawLine(9+16,0,11+16,0);
	drawLine(11+16,0,17+16,13);
	drawLine(17+16,13,23+16,0);
	drawLine(23+16,0,25+16,0);
	drawLine(25+16,0,19+16,16);
	drawLine(19+16,16,15+16,16);
	drawLine(15+16,16,9+16,0);

}

int main(void){
	init();
	//drawRect(0, 0, 10, 10);
	//drawRect(10, 10, 10, 10);
	
	drawPVV();



	// Ultimate loop
	for(;;){	
		asm("nop");	
	}
}


ISR(TCE1_OVF_vect){
	for(int i = 0; i < YRES; ++i)
	for(int j = 0; j < BUFXSZ-1 ; ++j)
	if(buffer[i][j]) 
		paint(i, j);
}
